import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Writer { // container to hold all the stats
	
	private pidStat pidstat;
	private pidSchedStat pidSched;
	private processStats process;
	private diskStat disk;
	private ioStat io;
	private cpuStat cpu;
	private memStat mem;
	
	Writer() {
		this.pidSched = new pidSchedStat();
		this.pidstat = new pidStat();
		this.cpu = new cpuStat();
		this.io = new ioStat();
		this.mem = new memStat();
		this.disk = new diskStat();
		this.process = new processStats();
	}
	
	public void writePidStat() throws IOException {
		this.pidstat.write("resourceStat.txt");
	}
	
	public void writePidSched() throws IOException {
		this.pidSched.write("resourceStat.txt");
	}
	public void writeProcess() throws IOException {
		this.process.write("resourceStat.txt");
	}
	public void writeDisk() throws IOException {
		this.disk.write("resourceStat.txt");
	}
	public void writeIO() throws IOException {
		this.io.write("resourceStat.txt");
	}
	public void writeCPU() throws IOException {
		this.cpu.write("resourceStat.txt");
	}
	public void writeMem() throws IOException {
		this.mem.write("resourceStat.txt");
	}
	
	public void transferStats(DataOutputStream out) throws IOException { // sends data to output stream of socket for back end server
		BufferedWriter bw = new BufferedWriter (new FileWriter (new File("resourceStat.txt"), true));
		bw.write("Over");
		bw.close();
		BufferedReader br = new BufferedReader (new FileReader (new File("resourceStat.txt")));
		String line;
		while ( (line = br.readLine()) != null) {
			out.writeUTF(line);
		}
		br.close();
		br = new BufferedReader (new FileReader (new File("dbData.txt")));
		while ( (line = br.readLine()) != null) {
			out.writeUTF(line);
		}
	}

	
	public void setPidstat(pidStat pidstat) {
		this.pidstat = pidstat;
	}

	

	public void setPidSched(pidSchedStat pidSched) {
		this.pidSched = pidSched;
	}

	
	public void setProcess(processStats process) {
		this.process = process;
	}

	public void setDisk(diskStat disk) {
		this.disk = disk;
	}


	public void setIo(ioStat io) {
		this.io = io;
	}

	public void setCpu(cpuStat cpu) {
		this.cpu = cpu;
	}


	public void setMem(memStat mem) {
		this.mem = mem;
	}


}
