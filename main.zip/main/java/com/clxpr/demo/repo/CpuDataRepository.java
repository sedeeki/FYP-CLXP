package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.CpuData;
public interface CpuDataRepository extends JpaRepository<CpuData, Long> {  // interface for storing cpu data in database 

}
