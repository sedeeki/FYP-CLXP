package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.MemData;

public interface MemDataRepository extends JpaRepository<MemData, Long> { // interface for storing memory data in database 

}
