package com.clxpr.demo.model.json;

public class DataPidSched { //model class for pid sched stats that is used to store data in json format for web application
	
	public DataPidSched(int usrId, String uid, String pid, String priority, String policy, String cmd, String time, Long Id) {
		super();
		this.usrId = usrId;
		this.uid = uid;
		this.pid = pid;
		this.priority = priority;
		this.policy = policy;
		this.cmd = cmd;
		this.time = time;
		this.Id = Id;
	}
	private int usrId;
	private String uid;
	private String pid;
	private String priority;
	private String policy;
	private String cmd;
	private String time;
	private Long Id;
	
	public int getUsrID() {
		return this.usrId;
	}
	
	public void setUsrId(int id) {
		this.usrId = id;
	}
	
	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		this.Id = id;
	}
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
}
