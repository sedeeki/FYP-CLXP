package StackDump;

class NotAuthorizedToCallThisMethodException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotAuthorizedToCallThisMethodException(String message) {
		super(message);
	}
	
}
