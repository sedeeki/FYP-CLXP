package StackDump;

class MethodNotSpecifiedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MethodNotSpecifiedException(String message) {
		super(message);
	}
	
}
