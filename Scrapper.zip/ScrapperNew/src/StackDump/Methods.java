package StackDump;

enum Methods {
	
	ONE_THREAD, ALL_THREAD, ALL_METHODS, ONE_METHOD;

}
