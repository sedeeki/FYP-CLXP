package com.clxpr.demo.controller;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.clxpr.demo.model.json.Data;
import com.clxpr.demo.model.json.DataCpu;
import com.clxpr.demo.model.json.DataDisk;
import com.clxpr.demo.model.json.DataHostSummary;
import com.clxpr.demo.model.json.DataIo;
import com.clxpr.demo.model.json.DataMem;
import com.clxpr.demo.model.json.DataPid;
import com.clxpr.demo.model.json.DataPidSched;
import com.clxpr.demo.repo.CpuDataRepository;
import com.clxpr.demo.repo.DiskDataRepository;
import com.clxpr.demo.repo.HostSummaryRepository;
import com.clxpr.demo.repo.IoDataRepository;
import com.clxpr.demo.repo.MemDataRepository;
import com.clxpr.demo.repo.PidDataRepository;
import com.clxpr.demo.repo.PidSchedDataRepository;
import com.clxpr.demo.repo.ResourceDataRepository;



@RestController
@RequestMapping("/api/v1/") // the MAIN path 
public class HomeController {  // auto wiring the repo classes for spring to instantiate the objects of these classes
@Autowired
ResourceDataRepository RDrepo;
@Autowired
CpuDataRepository CpuDrepo;
@Autowired
DiskDataRepository DiskDrepo;
@Autowired
IoDataRepository IoDrepo;
@Autowired
MemDataRepository MemDrepo;
@Autowired
PidDataRepository PidDrepo;
@Autowired
PidSchedDataRepository PidSchedDrepo;
@Autowired
HostSummaryRepository HostSummaryrepo;

	@GetMapping( 
	        path = "/resourceData", // process stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<Data> getRD(){
		Collection<Data> data = new ArrayList<Data>();
		RDrepo.findAll().forEach(d->{
			data.add(new Data(d.getUsrID(), d.getId(), d.getTime(), d.getUid(), d.getPid(), d.getRd(), d.getWr(), d.getCcwr(), d.getIodelay(), d.getCommand()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/cpuData",  // cpu stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataCpu> getCpuD(){
		Collection<DataCpu> data = new ArrayList<DataCpu>();
		CpuDrepo.findAll().forEach(d->{
			data.add(new DataCpu(d.getUsrID(), d.getTime(), d.getCpu(), d.getUsr(), d.getNice(), d.getSys(), d.getIoWait(), d.getIrq(), d.getSoft(), d.getSteal(), d.getGuest(), d.getGnice(), d.getIdle(), d.getId()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/diskData",  // disk stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataDisk> getDiskD(){
		Collection<DataDisk> data = new ArrayList<DataDisk>();
		DiskDrepo.findAll().forEach(d->{
			data.add(new DataDisk(d.getUsrID(),d.getLoop(), d.getTotal(), d.getMerged(), d.getSectors(), d.getMs(), d.getTota(), d.getMerged2(), d.getSectors2(), d.getMs2(), d.getCur(), d.getSec(), d.getId()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/ioData",  // io stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataIo> getIoD(){
		Collection<DataIo> data = new ArrayList<DataIo>();
		IoDrepo.findAll().forEach(d->{
			data.add(new DataIo(d.getUsrID(),d.getDevice(), d.getTps(), d.getReadSpeed(), d.getWriteSpeed(), d.getRead(), d.getWrite(), d.getId()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/memData",  // mem stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataMem> getMemD(){
		Collection<DataMem> data = new ArrayList<DataMem>();
		MemDrepo.findAll().forEach(d->{
			data.add(new DataMem(d.getUsrID(),d.getR(), d.getB(), d.getSwpd(), d.getFree(), d.getInact(), d.getActive(), d.getSi(), d.getSo(), d.getBi(), d.getBo(), d.getIn(), d.getCs(), d.getUs(),d.getSy(),d.getid(),d.getWa(),d.getSt(), d.getId()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/pidData",  // pid stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataPid> getPidD(){
		Collection<DataPid> data = new ArrayList<DataPid>();
		PidDrepo.findAll().forEach(d->{
			data.add(new DataPid(d.getUsrID(),d.getTime(),d.getUid(),d.getPid(),d.getUsr(),d.getSystem(),d.getGuest(),d.getWait(),d.getCpu(),d.getCpuNo(),d.getCmd(), d.getId()));
		});
		return data;
	}
	
	@GetMapping( 
	        path = "/pidSchedData",  // pid sched stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataPidSched> getPidSchedD(){
		Collection<DataPidSched> data = new ArrayList<DataPidSched>();
		PidSchedDrepo.findAll().forEach(d->{
			data.add(new DataPidSched(d.getUsrID(),d.getTime(), d.getUid(), d.getPid(), d.getPriority(), d.getPolicy(), d.getCmd(), d.getId()));
		});
		return data;
	}
	@GetMapping( 
	        path = "/statementAnalysis",  // pid sched stats extracted from database for web application 
	        produces = "application/json") 
	public Collection<DataHostSummary> getHostSummaryD(){
		Collection<DataHostSummary> data = new ArrayList<DataHostSummary>();
		HostSummaryrepo.findAll().forEach(d->{
			data.add(new DataHostSummary(d.getId(), d.getHost(), d.getStatement(), d.getStatement_latency(), d.getStatement_avg_lat(), d.getTable_scans(),
					d.getFile_ios(), d.getFile_io_lat(), d.getCurrent_connect(), d.getTotal_connect(), d.getUnique_users(), d.getCurrent_memory(),
					d.getTotal_memory_allocated()));
		});
		return data;
	}
}
