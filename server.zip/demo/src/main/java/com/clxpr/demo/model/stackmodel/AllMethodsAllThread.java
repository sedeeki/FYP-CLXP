package com.clxpr.demo.model.stackmodel;

import java.util.ArrayList;

public class AllMethodsAllThread {
	
	private ArrayList <AllMethodsOneThread> arr;

	public ArrayList<AllMethodsOneThread> getArr() {
		return arr;
	}

	public void setArr(ArrayList<AllMethodsOneThread> arr) {
		this.arr = arr;
	}
	
	
}
