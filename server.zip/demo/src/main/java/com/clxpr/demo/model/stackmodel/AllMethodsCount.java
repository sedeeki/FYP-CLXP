package com.clxpr.demo.model.stackmodel;

public class AllMethodsCount {

	private int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
