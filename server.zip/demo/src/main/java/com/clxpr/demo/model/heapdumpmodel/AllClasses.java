package com.clxpr.demo.model.heapdumpmodel;

import java.util.ArrayList;

public class AllClasses {

	private ArrayList <String> classes;

	public ArrayList<String> getClasses() {
		return classes;
	}

	public void setClasses(ArrayList<String> classes) {
		this.classes = classes;
	}
	
	
	
}
