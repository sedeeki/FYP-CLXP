package com.clxpr.demo.model.threadmodel;

import java.util.ArrayList;

public class BlockedCount {
	
	private ArrayList <String> id;
	private ArrayList <String> count;
	
	public ArrayList<String> getId() {
		return id;
	}
	public void setId(ArrayList<String> id) {
		this.id = id;
	}
	public ArrayList<String> getCount() {
		return count;
	}
	public void setCount(ArrayList<String> count) {
		this.count = count;
	}
	
	

	
	
	
}
