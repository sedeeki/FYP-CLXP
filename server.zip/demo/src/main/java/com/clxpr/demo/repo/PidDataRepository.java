package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.PidData;

public interface PidDataRepository extends JpaRepository<PidData, Long> { // interface for storing pid data in database 

}
