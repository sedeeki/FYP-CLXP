package com.clxpr.demo.model.heapdumpmodel;

public class TotalInstances {
	
	private long instances;

	public long getInstances() {
		return instances;
	}

	public void setInstances(long instances) {
		this.instances = instances;
	}
	

}
