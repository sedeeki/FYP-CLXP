package com.clxpr.demo.model.heapdumpmodel;

public class ClassMemory {
	
	private String name;
	private long memory;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMemory() {
		return memory;
	}
	public void setMemory(long memory) {
		this.memory = memory;
	}

}
