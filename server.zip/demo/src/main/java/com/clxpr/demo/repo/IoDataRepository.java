package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.IoData;

public interface IoDataRepository extends JpaRepository<IoData, Long> {  // interface for storing io data in database 

}
