package com.clxpr.demo.model.heapdumpmodel;

public class ClassInstance {
	
	private String name;
	private long instances;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getInstances() {
		return instances;
	}
	public void setInstances(long instances) {
		this.instances = instances;
	}
	

}
