package com.clxpr.demo.model.heapmodel;

import java.util.ArrayList;

public class Heap {
	
	private ArrayList <String> name;
	private ArrayList <String> instances;
	private ArrayList <String> memory;
	
	public ArrayList<String> getName() {
		return name;
	}
	public void setName(ArrayList<String> name) {
		this.name = name;
	}
	public ArrayList<String> getInstances() {
		return instances;
	}
	public void setInstances(ArrayList<String> instances) {
		this.instances = instances;
	}
	public ArrayList<String> getMemory() {
		return memory;
	}
	public void setMemory(ArrayList<String> memory) {
		this.memory = memory;
	}
	
	
	
	
}
