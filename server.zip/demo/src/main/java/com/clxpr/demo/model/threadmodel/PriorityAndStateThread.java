package com.clxpr.demo.model.threadmodel;

import java.util.ArrayList;

public class PriorityAndStateThread {
	
	private ArrayList <String> id;
	private ArrayList <String> state;
	private ArrayList <String> priority;
	
	public ArrayList<String> getId() {
		return id;
	}
	public void setId(ArrayList<String> id) {
		this.id = id;
	}
	public ArrayList<String> getState() {
		return state;
	}
	public void setState(ArrayList<String> state) {
		this.state = state;
	}
	public ArrayList<String> getPriority() {
		return priority;
	}
	public void setPriority(ArrayList<String> priority) {
		this.priority = priority;
	}
	
	

}
