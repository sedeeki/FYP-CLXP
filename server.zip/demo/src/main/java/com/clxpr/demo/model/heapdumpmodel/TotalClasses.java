package com.clxpr.demo.model.heapdumpmodel;

public class TotalClasses {

	private int classes;

	public int getClasses() {
		return classes;
	}

	public void setClasses(int classes) {
		this.classes = classes;
	}
	
}
