package com.clxpr.demo.model.heapdumpmodel;

public class TotalMemoryUsed {

	
	private long memory;

	public long getMemory() {
		return memory;
	}

	public void setMemory(long memory) {
		this.memory = memory;
	}
	
}
