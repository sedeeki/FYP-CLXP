package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.HostSummaryData;
public interface HostSummaryRepository extends JpaRepository<HostSummaryData, Long> {  // interface for storing data in database
	
}

