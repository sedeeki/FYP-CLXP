package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.ResourceData;
public interface ResourceDataRepository extends JpaRepository<ResourceData, Long> { // interface for storing process data in database 

}
