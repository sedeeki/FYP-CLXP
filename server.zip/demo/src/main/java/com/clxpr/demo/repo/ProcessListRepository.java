package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.ProcessListData;
public interface ProcessListRepository extends JpaRepository<ProcessListData, Long> { // interface for storing data in database
	
}

