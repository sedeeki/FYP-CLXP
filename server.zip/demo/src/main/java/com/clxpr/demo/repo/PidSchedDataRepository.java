package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.PidSchedData;

public interface PidSchedDataRepository extends JpaRepository<PidSchedData, Long> { // interface for storing pid sched data in database 

}
