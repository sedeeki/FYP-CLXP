package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.clxpr.demo.model.db.StatementAnalysisData;


public interface StatementAnalysisRepository extends JpaRepository<StatementAnalysisData, Long> { // interface for storing data in database
	
}

