package com.clxpr.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.DiskData;

public interface DiskDataRepository extends JpaRepository<DiskData, Long> { // interface for storing disk data in database 

}
