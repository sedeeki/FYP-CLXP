package com.clxpr.demo.model.threadmodel;

import java.util.ArrayList;

public class CpuTimeForThread {
	
	private ArrayList <String> id;
	private ArrayList <String> time;

	public ArrayList<String> getTime() {
		return time;
	}

	public void setTime(ArrayList<String> time) {
		this.time = time;
	}

	public ArrayList<String> getId() {
		return id;
	}

	public void setId(ArrayList<String> id) {
		this.id = id;
	}
	

	
}
