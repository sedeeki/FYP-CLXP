package com.clxpr.demo.repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.clxpr.demo.model.db.Resource;
public interface ResourceRepository extends JpaRepository<Resource, Long>{

}
