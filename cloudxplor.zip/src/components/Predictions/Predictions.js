import React, { Component } from 'react';

class Predictions extends Component {
  state = {
    isLoading: true,
    groups: []
  };

  async componentDidMount() {
    const response = await fetch('http://localhost:8080/api/v1/ioData');
    const body = await response.json();
    this.setState({ groups: body, isLoading: false });
  }

  render() {
    const {groups, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (
      <div className="resource-monitor">
        <header className="App-header">
          <div>
            <h2>Table</h2>
            <table>
              <thead>
                <th>id</th>
                <th>device</th>
                <th>tps</th>
                
                <th>read</th>
                <th>write</th>
              </thead>
              <tbody>
              {groups.map(group =>
              <tr>
                <td>{group.Id}</td>
                <td>{group.device_col}</td>
                <td>{group.tps_col}</td>
                
                <td>{group.read_col}</td>
                <td>{group.write_col}</td>
              </tr>
            )}
              </tbody>
            </table>
          </div>
        </header>
      </div>
    );
  }
}

export default Predictions;