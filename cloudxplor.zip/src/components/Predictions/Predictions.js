import React, { Component } from 'react';

class Predictions extends Component {
  state = {
    isLoading: true,
    groups: []
  };

  async componentDidMount() {
    const response = await fetch('http://localhost:8080/api/v1/statementAnalysis');
    const body = await response.json();
    this.setState({ groups: body, isLoading: false });
    console.log(body);
  }

  render() {
    const {groups, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (
      <div className="resource-monitor">
        <header className="App-header">
          <div>
            <h2>Table</h2>
            <table >
              <thead>
                <th>Id</th>
                <th>Host</th>
                <th>Statement</th>
                <th>Statement Latency</th>
                <th>Statement Avg Latency</th>
                <th>Table Scans</th>
                <th>File IOs</th>
                <th>File IO Latency</th>
                <th>Current Connect</th>
                <th>Total Connect</th>
                <th>Unique UsersM</th>
                <th>Current Mem</th>
                <th>Total Mem All</th>
              </thead>
              <tbody>
              {groups.map(group =>
              <tr>
                <td>{group.id}</td>
                <td>{group.host}</td>
                <td>{group.statement}</td>
                <td>{group.statement_latency}</td>
                <td>{group.statement_avg_lat}</td>
                <td>{group.table_scans}</td>
                <td>{group.file_ios}</td>
                <td>{group.file_io_lat}</td>
                <td>{group.current_connect}</td>
                <td>{group.total_connect}</td>
                <td>{group.unique_users}</td>
                <td>{group.current_memory}</td>
                <td>{group.total_memory_allocated}</td>
              </tr>
            )}
              </tbody>
            </table>
          </div>
        </header>
      </div>
    );
  }
}

export default Predictions;