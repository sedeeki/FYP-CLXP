import React, {Component} from 'react';

class Predictions extends Component {

  state = {
    isLoading: true,
    groups: []
  };

  async componentDidMount() {
    const response = await fetch('http://localhost:8080/api/v1/StatementAnalysis');
    const body = await response.json();
    this.setState({ groups: body, isLoading: false });
    console.log(body);
  }



  render() {
    const {isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (
      <div className="resource-monitor">
        <header className="App-header">
          <div>
            <h2>PREDICTIONS</h2>
            {/* <Table bordered hover>
              <thead>
                <th>Id</th>
                <th>Host</th>
                <th>Statement</th>
                <th>Total</th>
                <th>Total Latency</th>
                <th>Max Latency</th>
                <th>Lock Latency</th>
                <th>Rows Sent</th>
                <th>Rows Examined</th>
                <th>Rows Affected</th>
                <th>Full Scans</th>
              </thead>
              <tbody>
              {groups.map(group =>
              <tr>
                <td>{group.id}</td>
                <td>{group.host}</td>
                <td>{group.statement}</td>
                <td>{group.total}</td>
                <td>{group.total_latency}</td>
                <td>{group.max_latency}</td>
                <td>{group.lock_latency}</td>
                <td>{group.rows_sent}</td>
                <td>{group.rows_examined}</td>
                <td>{group.rows_affected}</td>
                <td>{group.full_scans}</td>
              </tr>
            )}
              </tbody>
            </Table> */}
          </div>
        </header>
      </div>
    );
  }
}

export default Predictions;