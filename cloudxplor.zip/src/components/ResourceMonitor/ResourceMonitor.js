import React, { Component } from 'react';

class ResourceMonitor extends Component {
  state = {
    isLoading: true,
    groups: []
  };

  async componentDidMount() {
    const response = await fetch('http://localhost:8080/api/v1/resourceData');
    const body = await response.json();
    this.setState({ groups: body, isLoading: false });
  }

  render() {
    const {groups, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (
      <div className="resource-monitor">
        <header className="App-header">
          <div>
            <h2>Table</h2>
            <table>
              <thead>
                <th>id</th>
                <th>command</th>
                <th>IO Delay</th>
                <th>PID</th>
                <th>UID</th>
                <th>Time</th>
                <th>Rd</th>
                <th>WR</th>
                <th>CCWR</th>
              </thead>
              <tbody>
              {groups.map(group =>
              <tr>
                <td>{group.id}</td>
                <td>{group.command}</td>
                <td>{group.iodelay}</td>
                <td>{group.pid}</td>
                <td>{group.uid}</td>
                <td>{group.time}</td>
                <td>{group.rd}</td>
                <td>{group.wr}</td>
                <td>{group.ccwr}</td>
              </tr>
            )}
              </tbody>
            </table>
          </div>
        </header>
      </div>
    );
  }
}

export default ResourceMonitor;