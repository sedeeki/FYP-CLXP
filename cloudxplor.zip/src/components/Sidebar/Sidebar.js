import React, {useState} from "react";
import './Sidebar.css';
import { Link } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';

function Sidebar() {
  const [sidebar,setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);

  const closeSidebar = () => setSidebar(false);

  return (
    <>
    <nav className={sidebar ? 'sidebar active' : 'sidebar'}>
      <ul className="sidebar-side">
        <li className="logo">
          <Link to='#' className='side-link' onClick={showSidebar}>
            <span className="link-text logo-text">Cloud Xplor</span>
            <FaIcons.FaAngleDoubleRight size='2rem'/>
          </Link>
        </li>
        <li className="side-item" onClick={closeSidebar}>
          <Link to='/' className='side-link'>
            <FaIcons.FaHome size='2rem'/>
            <span className="link-text">Dashboard</span>
          </Link>
        </li>
        <li className="side-item" onClick={closeSidebar}>
          <Link to='resourcemonitor' className='side-link'>
            <FaIcons.FaSearch size='2rem'/>
            <span className="link-text">Resource Monitor</span>
          </Link>
        </li>
        <li className="side-item" onClick={closeSidebar}>
          <Link to='codeprofiler' className='side-link'>
            <FaIcons.FaAlignLeft size='2rem' />
            <span className="link-text">Code Profiler</span>
          </Link>
        </li>
        <li className="side-item" onClick={closeSidebar}>
          <Link to='register' className='side-link'>
            <FaIcons.FaChartLine size='2rem'/>
            <span className="link-text">Predictions</span>
          </Link>
        </li>
      </ul> 
    </nav> 
    </>
  );
}

export default Sidebar;