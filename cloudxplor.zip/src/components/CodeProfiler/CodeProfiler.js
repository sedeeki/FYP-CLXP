import React, { Component } from 'react';

class CodeProfiler extends Component {
  state = {
    isLoading: true,
    groups: []
  };

  async componentDidMount() {
    
    const codeProfilerResponse = await fetch('http://localhost:8080/api/v1/StackDump');
    const codeProfilerBody = await codeProfilerResponse.json();
    console.log(codeProfilerBody);


  }

  render() {
    
    return (
      <div className="resource-monitor">
        <header className="App-header">
          <div>
            <h2>CODE PROFILER</h2>
            
          </div>
        </header>
      </div>
    );
  }
}

export default CodeProfiler;