import React, {useState}  from "react";
import './Home.css';
// eslint-disable-next-line no-unused-vars
import { Container, Row, Col, Form, FormControl, Navbar, Nav, ListGroup } from 'react-bootstrap';
import Image from 'react-bootstrap/Image';
import CanvasJSReact from './../../canvasjs.react';
import * as FiIcons from 'react-icons/fi';


function Home() {

var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;

const [iodelay,setIoDelay] = useState("9");
const [cpu,setCpu] = useState("2");
const [priority,setPriority] = useState("-");
const [policy,setPolicy] = useState("-");
const [command,setCommand] = useState("irqbalance");
const [cpuPercentage,setCpuPercentage] = useState("0.03 %");

const currentdate = new Date().toDateString();

const memData = {
  animationEnabled: true,
  theme: "light2",
  axisX: {
    title: "Memory (KB)",
    reversed: true,
  },
  data: [{
    type: "bar",
    dataPoints: [
      { y:  315080, label: "free" },
      { y:  1476664, label: "inactive" },
      { y:  5810424, label: "active" },
    ]
  }]
}

const cpuData = {
  exportEnabled: true,
  animationEnabled: true,
  
  data: [{
    type: "pie",
    startAngle: 75,
    toolTipContent: "<b>{label}</b>: {y}%",
    showInLegend: "true",
    legendText: "{label}",
    indexLabelFontSize: 16,
    indexLabel: "{label} - {y}%",
    dataPoints: [
      { y: 3.13, label: "%usr" },
      { y: 0.23, label: "%nice" },
      { y: 0.56, label: "%sys" },
      { y: 0.14, label: "%iowait" },
      { y: 0.00, label: "%irq" },
      { y: 0.05, label: "%soft" },
      { y: 0.00, label: "%steal" },
      { y: 0.00, label: "%guest" },
      { y: 0.00, label: "%gnice" },
      { y: 95.89, label: "%idle" },
    ]
  }]
}

const diskData = {
  data: [
  {
    // Change type to "doughnut", "line", "splineArea", etc.
    type: "column",
    dataPoints: [
      { label: "rd_total",  y: 63145  },
      { label: "rd_merged", y: 22116   },
      { label: "wr_total",  y: 245791 },
      { label: "wr_merged", y: 288520   },
    ]
  }
  ]
}

function firstClicked() {
  setCommand("migration/0");
  setIoDelay("-");
  setCpu("0");
  setCpuPercentage("0.00 %");
  setPriority("99");
  setPolicy("FIFO");
}

function secondClicked() {
  setCommand("migration/0");
  setIoDelay("-");
  setCpu("1");
  setCpuPercentage("0.01 %");
  setPriority("50");
  setPolicy("FIFO");
}

function thirdClicked() {
  setCommand("irqbalance");
  setIoDelay("9");
  setCpu("2");
  setCpuPercentage("0.00 %");
  setPriority("-");
  setPolicy("-");
}

function fourthClicked() {
  setCommand("NetworkManager");
  setIoDelay("301");
  setCpu("0");
  setCpuPercentage("0.00 %");
  setPriority("-");
  setPolicy("-");
}

function fifthClicked() {
  setCommand("gdm3");
  setIoDelay("7");
  setCpu("3");
  setCpuPercentage("0.00 %");
  setPriority("-");
  setPolicy("-");
}

function sixthClicked() {
  setCommand("whoopsie");
  setIoDelay("43");
  setCpu("3");
  setCpuPercentage("0.00 %");
  setPriority("-");
  setPolicy("-");
}

function seventhClicked() {
  setCommand("dbus-daemon");
  setIoDelay("28");
  setCpu("0");
  setCpuPercentage("0.00 %");
  setPriority("-");
  setPolicy("-");
}

  return (
    <div className='home'>
      <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
        <Navbar className="nav-color">
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Form className="mr-auto form">
              <FormControl type="text" placeholder="Search" className="my-search"/>
            </Form>
            <FiIcons.FiBell size='1.5rem' className="icon-left"/>
            <FiIcons.FiSettings size='1.5rem' className="icon-right"/>
            <Image src={require('../../images/profile50x50.png')} roundedCircle/>
          </Navbar.Collapse>
        </Navbar>
      </Container>
      <Container fluid>
        <Row className="heading">
          <Col>
            <h1>Dashboard</h1>
            <h5>{currentdate}</h5>
          </Col>
        </Row>

        <Row>
          <Col md={5}>
            <div className="box4">
              <Container style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  Memstat
                </h3>
                <Row>
                  <Col style={{padding:48}}>
                    <CanvasJSChart options = {memData}/* onRef={ref => this.chart = ref} *//>
                  </Col>
                </Row>
              </Container>
            </div>
          </Col>

          <Col>
          <div className="box4">
              <Container style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  CPU Stats
                </h3>
                <Row>
                  <Col style={{padding:48}}>
                    <CanvasJSChart options = {cpuData}/* onRef={ref => this.chart = ref} *//>
                  </Col>
                </Row>
              </Container>
            </div>
          </Col>
        </Row>
        
        <Row className="row-margin">
          <Col md={8}>
            <div className="box4">
              <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  Processes
                </h3>
                <Row>
                  <Col md={3} style={{padding:32}}>
                    <h5>Proccess Ids</h5>
                    <ListGroup >
                      <ListGroup.Item action onClick={firstClicked}>12  - migration/0</ListGroup.Item>
                      <ListGroup.Item action onClick={secondClicked}>484 - irq/18-vmwgfx</ListGroup.Item>
                      <ListGroup.Item action onClick={thirdClicked}>629 - irqbalance</ListGroup.Item>
                      <ListGroup.Item action onClick={fourthClicked}>670 - NetworkManager</ListGroup.Item>
                      <ListGroup.Item action onClick={fifthClicked}>733 - gdm3</ListGroup.Item>
                      <ListGroup.Item action onClick={sixthClicked}>801 - whoopsie</ListGroup.Item>
                      <ListGroup.Item action onClick={seventhClicked}>873 - dbus-daemon</ListGroup.Item>
                    </ListGroup>
                  </Col>
                  <Col style={{padding:32}} className="d-flex align-items-center" >
                    <Container fluid>
                      <Row className="row-margin">
                        <Col md={4}>
                          <h4>Command</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{command}</h3>
                          </div>
                        </Col>
                        <Col md={4}>
                          <h4>IO Delay</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{iodelay}</h3>
                          </div>
                        </Col>
                        <Col md={4}>
                          <h4>CPU</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{cpu}</h3>
                          </div>
                        </Col>
                      </Row>
                      <Row className="row-margin">
                        <Col md={4}>
                          <h4>Priority</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{priority}</h3>
                          </div>
                        </Col>
                        <Col md={4}>
                          <h4>Policy</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{policy}</h3>
                          </div>
                        </Col>
                        <Col md={4}>
                          <h4>CPU%</h4>
                          <div className="box2 d-flex justify-content-center align-items-center">
                            <h3>{cpuPercentage}</h3>
                          </div>
                        </Col>
                      </Row>
                    </Container>  
                  </Col>
                </Row>
              </Container>
            </div>
          </Col >

          <Col md={4}>
            <div className="box4">
              <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  Disk Stat
                </h3>
              <Row>
              <Col style={{padding:20}}>
                <Container fluid>
                  <Row>
                    <Col>
                      <CanvasJSChart options = {diskData}/* onRef={ref => this.chart = ref} *//>
                    </Col>
                  </Row>
                </Container>  
              </Col>
                </Row>
              </Container>
            </div>
          </Col >
        </Row>
      </Container>
    </div>
  );
}

export default Home;
