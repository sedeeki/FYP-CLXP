import React, { Component } from 'react';
import './Home.css'
import { HiOutlineArrowNarrowUp, HiOutlineArrowNarrowDown } from 'react-icons/hi'
import { Container, Row, Col, Card, ListGroup } from 'react-bootstrap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart} from 'recharts';
import { PieChart, Pie, Sector } from "recharts";


const renderActiveShape = (props) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill}>
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#333">{`Value = ${value}`}</text>
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} dy={18} textAnchor={textAnchor} fill="#999">
        {`(Rate ${(percent * 100).toFixed(2)}%)`}
      </text>
    </g>
  );
};

class Home extends Component {

  onPieEnter = (_, index) => {
    this.setState({
      activeIndex: index,
    });
  };

  state = {

    activeIndex: 0,

    //Memory Data
    free : 0, 
    inact : 0,
    active : 0,

    //CPU Data
    usr : 0,
    nice : 0,
    sys : 0,
    ioWait : 0,
    irq : 0,
    soft : 0,
    steal : 0,
    guest : 0,
    gnice : 0,
    idle : 0,

    //DiskData
    rd_total : 0,
    rd_merged : 0,
    wr_total : 0,
    wr_merged : 0,

    //IoData
    ioData : [],
    device_id: 8,
    tps : 0,
    readSpeed : 0,
    writeSpeed : 0,
    read : 0,
    write : 0,
    tps_difference : 0,
    readSpeed_difference : 0,
    writeSpeed_difference : 0,
    read_difference : 0,
    write_difference : 0,

    //Used for difference calculation
    oldIoData : []
  };

  componentDidMount() {
    this.updateMemData()
    setInterval(this.updateMemData, 20000);

    this.updateDiskData()
    setInterval(this.updateDiskData, 20000);
    
    this.updateCpuData()
    setInterval(this.updateCpuData, 20000);

    this.fetchIoData()
    setInterval(this.updateIoData, 20000);
  }

  updateMemData = async () => {
    const memDataresponse = await fetch('http://localhost:8080/api/v1/memData');
    const memDataBody = await memDataresponse.json();
    this.setState({
      free : parseInt(memDataBody[memDataBody.length-1].free),
      inact : parseInt(memDataBody[memDataBody.length-1].inact),
      active: parseInt(memDataBody[memDataBody.length-1].active),
    })
  }

  updateDiskData = async () => {
    const diskDataResponse = await fetch('http://localhost:8080/api/v1/diskData');
    const diskDataBody = await diskDataResponse.json();
    this.setState({
      rd_total : parseInt(diskDataBody[diskDataBody.length-1].total),
      rd_merged : parseInt(diskDataBody[diskDataBody.length-1].merged),
      wr_total: parseInt(diskDataBody[diskDataBody.length-1].total2),
      wr_merged: parseInt(diskDataBody[diskDataBody.length-1].merged2),
    })
  }

  updateCpuData = async () => {
    const cpuDataResponse = await fetch('http://localhost:8080/api/v1/cpuData');
    const cpuDataBody= await cpuDataResponse.json();
    this.setState({
      usr : parseInt(cpuDataBody[0].usr),
      ioWait: parseInt(cpuDataBody[0].ioWait),
      idle: parseInt(cpuDataBody[0].idle),
      sys : parseInt(cpuDataBody[0].sys),
    })
  }

  fetchIoData = async () => {
    const ioDataResponse = await fetch('http://localhost:8080/api/v1/ioData/');
    const ioDataBody = await ioDataResponse.json();

    let temp = parseInt(ioDataBody[this.state.device_id].write_col);
    temp = temp / 1000000;
    temp = temp.toFixed(2);

    this.setState({
      ioData : ioDataBody,
      tps : parseInt(ioDataBody[this.state.device_id].tps_col),
      readSpeed : parseInt(ioDataBody[this.state.device_id].readSpeed_col),
      writeSpeed : parseInt(ioDataBody[this.state.device_id].writeSpeed_col),
      write : temp,
    })

    this.setState({
      oldIoData : ioDataBody
    })
  }

  updateIoData = async () => {
    const ioDataResponse = await fetch('http://localhost:8080/api/v1/ioData/');
    const ioDataBody = await ioDataResponse.json();

    let temp = parseInt(ioDataBody[this.state.device_id].write_col);
    temp = temp / 1000000;
    temp = temp.toFixed(2);

    this.setState({
      ioData : ioDataBody,
      tps : parseInt(ioDataBody[this.state.device_id].tps_col),
      readSpeed : parseInt(ioDataBody[this.state.device_id].readSpeed_col),
      writeSpeed : parseInt(ioDataBody[this.state.device_id].writeSpeed_col),
      write : temp,
    })
    this.calculateDifference(this.state.oldIoData,ioDataBody)
    this.setState({
      oldIoData : ioDataBody
    })
  }

  calculateDifference(oldData,newData){
    let temp = parseInt(newData[this.state.device_id].write_col) - parseInt(oldData[this.state.device_id].write_col);
    temp = temp / 1000000;
    temp = temp.toFixed(2);
    this.setState({
      tps_difference : parseInt(newData[this.state.device_id].tps_col) - parseInt(oldData[this.state.device_id].tps_col),
      readSpeed_difference : parseInt(newData[this.state.device_id].readSpeed_col) - parseInt(oldData[this.state.device_id].readSpeed_col),
      writeSpeed_difference :  parseInt(newData[this.state.device_id].writeSpeed_col) -  parseInt(oldData[this.state.device_id].writeSpeed_col),
      write_difference : temp,
    })
  }


  ioDeviceClicked (index) {
    const {
      ioData,
    } = this.state;

    let temp = parseInt(ioData[index].write_col);
    temp = temp / 1000000;
    temp = temp.toFixed(2);
    
    this.setState( {
        tps: parseInt(ioData[index].tps_col),
        readSpeed: parseInt(ioData[index].readSpeed_col),
        writeSpeed: parseInt(ioData[index].writeSpeed_col),
        read: parseInt(ioData[index].read_col),
        write: temp,
        device_id : index,
    });
}

  
  render() {

    const rechartMemoryData = [
      {
        name: 'Free',
        memdata: this.state.free,
      },
      {
        name: 'Inactive',
        memdata: this.state.inact,
      },
      {
        name: 'Active',
        memdata: this.state.active,
      }
    ];

    const rechartDiskData = [
      {
        name: 'rd_total',
        diskData: this.state.rd_total,
      },
      {
        name: 'rd_merged',
        diskData: this.state.rd_merged,
      },
      {
        name: 'wr_total',
        diskData: this.state.wr_total,
      },
      {
        name: 'wr_merged',
        diskData: this.state.wr_merged,
      }
    ];

    const reachartPieData = [
      { 
        name: '%idle', 
        value: this.state.idle
      },
      { 
        name: '%ioWait', 
        value: this.state.ioWait
      },
      { 
        name: '%usr', 
        value: this.state.usr
      },
      { 
        name: '%sys', 
        value: this.state.sys
      },
    ];

    return (
        <div className='main-content'>
        <Container fluid>
  
          <Row className="heading">
            <Col>
              <h2 className="main-heading">Hello, Mustafa Shah</h2>
              <h5 className="sub-heading">This is your dashboard</h5>
            </Col>
          </Row>
  
          <Row>
            <Col md={7}>
              <div className="first-box">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">Memory Stats</Card.Title>
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart
                        layout="vertical"
                        data={rechartMemoryData}
                        margin={{
                          top: 20,
                          right: 20,
                          bottom: 20,
                          left: 20,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3"/>
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" scale="band" />
                        <Tooltip />
                        <Bar dataKey="memdata" barSize={30} className="my-bar" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </Card.Body>
                </Card>
              </div>
              
            </Col>  
  
            <Col md={5}>
              <div className="first-box">
                <Card>
                  <Card.Body>
                    <Card.Title className="main-heading">CPU Stats</Card.Title>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart width={400} height={400}>
                          <Pie
                            activeIndex={this.state.activeIndex}
                            activeShape={renderActiveShape}
                            data={reachartPieData}
                            innerRadius={60}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            onMouseEnter={this.onPieEnter}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                  </Card.Body>
                </Card>
              </div>
            </Col>
          </Row>
  
          <Row>
            <Col md={3}>
              <div className="second-box second-box-first-div">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">TPS</Card.Title>
                    <div className="second-box-inside-div">
                      <div className="line"></div>
                      <Card.Text className="second-box-text">
                        {this.state.tps}
                      </Card.Text>
                      {
                        this.state.tps_difference >= 0 && <HiOutlineArrowNarrowUp className="arrow-icon-up"/>
                      }
                      {
                        this.state.tps_difference < 0 && <HiOutlineArrowNarrowDown className="arrow-icon-down"/>
                      }
                      <Card.Text className="second-box-diffrence-text">
                        {this.state.tps_difference}
                      </Card.Text>
                    </div>
                  </Card.Body>
                </Card>                
              </div>
            </Col>
  
            <Col md={3}> 
              <div className="second-box second-box-second-div">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">Read Speed</Card.Title>
                    <div className="second-box-inside-div">
                      <div className="line"></div>
                      <Card.Text className="second-box-text">
                        {this.state.readSpeed}
                      </Card.Text>
                      <Card.Text className="second-box-unit-text">
                        Kb/s
                      </Card.Text>
                      {
                        this.state.readSpeed_difference >= 0 && <HiOutlineArrowNarrowUp className="arrow-icon-up"/>
                      }
                      {
                        this.state.readSpeed_difference < 0 && <HiOutlineArrowNarrowDown className="arrow-icon-down"/>
                      }
                      <Card.Text className="second-box-diffrence-text">
                        {this.state.readSpeed_difference}
                      </Card.Text>
                    </div>
                  </Card.Body>
                </Card>     
              </div>
            </Col>
                  
            <Col md={3}>
              <div className="second-box second-box-third-div">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">Write Speed</Card.Title>
                    <div className="second-box-inside-div">
                      <div className="line"></div>
                      <Card.Text className="second-box-text">
                        {this.state.writeSpeed}
                      </Card.Text>
                      <Card.Text className="second-box-unit-text">
                        Kb/s
                      </Card.Text>
                      {
                        this.state.writeSpeed_difference >= 0 && <HiOutlineArrowNarrowUp className="arrow-icon-up"/>
                      }
                      {
                        this.state.writeSpeed_difference < 0 && <HiOutlineArrowNarrowDown className="arrow-icon-down"/>
                      }
                      <Card.Text className="second-box-diffrence-text">
                        {this.state.writeSpeed_difference}
                      </Card.Text>
                    </div>
                  </Card.Body>
                </Card>    
              </div>
            </Col>
            
            <Col md={3}>
              <div className="second-box second-box-fourth-div">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">Total Writes</Card.Title>
                    <div className="second-box-inside-div">
                      <div className="line"></div>
                      <Card.Text className="second-box-text">
                        {this.state.write}
                      </Card.Text>
                      <Card.Text className="second-box-unit-text">
                        GBs
                      </Card.Text>
                      {
                        this.state.write_difference >= 0 && <HiOutlineArrowNarrowUp className="arrow-icon-up"/>
                      }
                      {
                        this.state.write_difference < 0 && <HiOutlineArrowNarrowDown className="arrow-icon-down"/>
                      }
                      <Card.Text className="second-box-diffrence-text">
                        {this.state.write_difference}
                      </Card.Text>
                    </div>
                  </Card.Body>
                </Card>
              </div>
            </Col>
          </Row>
  
          <Row>
            <Col md={8}>
              <div className="third-box">
                <Card>
                  <Card.Body className="card-body">
                    <Card.Title className="main-heading">IO Devices</Card.Title>
                    <div className="list-div">
                      <ListGroup>
                          { this.state.ioData.map( (data,index) => 
                              <ListGroup.Item action onClick={() => this.ioDeviceClicked(index)}>{data.device_col}</ListGroup.Item>
                          )}
                      </ListGroup>
                    </div>
                  </Card.Body>
                </Card>
              </div>
              
            </Col>  
  
            <Col md={4}>
              <div className="third-box">
                <Card>
                  <Card.Body>
                    <Card.Title className="main-heading">Disk Stats</Card.Title>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={rechartDiskData}
                        margin={{
                          top: 10,
                          right: 30,
                          left: 0,
                          bottom: 10,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="diskData" barSize={30} fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </Card.Body>
                </Card>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Home;