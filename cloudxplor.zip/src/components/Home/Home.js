import React, {useState, useRef, useEffect}  from "react";
import './Home.css';
// eslint-disable-next-line no-unused-vars
import { Container, Row, Col, Form, FormControl, Navbar, Nav, ListGroup, Button } from 'react-bootstrap';
import Image from 'react-bootstrap/Image';
import CanvasJSReact from './../../canvasjs.react';
import * as FiIcons from 'react-icons/fi';
import { useHistory } from 'react-router-dom'
import { db } from '../../firebase'
import { useAuth } from '../../contexts/AuthContext'
import DeviceList from '../DeviceList/DeviceList'


function Home() {
  var CanvasJSChart = CanvasJSReact.CanvasJSChart;

  var memoryData
  const [free, setFree] = useState(0)
  const [inact, setInact] = useState(0)
  const [active, setActive] = useState(0) 
  let chart = useRef();

  const memData = {
    animationEnabled: true,
    theme: "light2",
    axisX: {
      title: "Memory (KB)",
      reversed: true,
    },
    data: [{
      type: "bar",
      dataPoints: [
        { y:  free ,  label: "free" },
        { y:  inact ,  label: "inactive" },
        { y:  active , label: "active" },
      ]
    }]
  }

  useEffect(()=>{
    updateMemoryData();
  },[])
  useEffect(() => {
    setInterval(() => {
      updateMemoryData();
    }, 22000)

  });

  async function updateMemoryData(){
    const response = await fetch('http://localhost:8080/api/v1/memData');
    
    const body = await response.json();
    memoryData = body;
    // console.log(memoryData.length);
    // console.log(memoryData[memoryData.length - 1]);
    setActive(parseInt(memoryData[memoryData.length - 1].active))
    setInact(parseInt(memoryData[memoryData.length - 1].inact))
    setFree(parseInt(memoryData[memoryData.length - 1].free))
    ////console.log(active, inact, free); 
  }

  var diskData
  const [rd_total, setRd_total] = useState(0)
  const [rd_merged, setRd_merged] = useState(0)
  const [wr_total, setWr_total] = useState(0)
  const [wr_merged, setWr_merged] = useState(0)

  const chartDiskData = {
    data: [
    {
      // Change type to "doughnut", "line", "splineArea", etc.
      type: "column",
      dataPoints: [
        { label: "rd_total",  y: rd_total  },
        { label: "rd_merged", y: rd_merged   },
        { label: "wr_total",  y: wr_total },
        { label: "wr_merged", y: wr_merged   },
      ]
    }
    ]
  }

  useEffect(()=>{
    updateDiskData();
  },[])
  useEffect(() => {
    setInterval(() => {
      updateDiskData();
    }, 22000)

  });

  async function updateDiskData(){
    const response = await fetch('http://localhost:8080/api/v1/diskData');
    
    const body = await response.json();
    diskData = body;
    // console.log(diskData.length);
    // console.log(diskData);
    setRd_total(parseInt(diskData[diskData.length - 1].total))
    setRd_merged(parseInt(diskData[diskData.length - 1].merged))
    setWr_total(parseInt(diskData[diskData.length - 1].total2))
    setWr_merged(parseInt(diskData[diskData.length - 1].merged2))
    //console.log(rd_total, rd_merged, wr_total, wr_merged); 
  }

  var cpuData
  const [usr, setUsr] = useState(0)
  const [nice, setNice] = useState(0)
  const [sys, setSys] = useState(0)
  const [ioWait, setIowait] = useState(0)
  const [irq, setIrq] = useState(0)
  const [soft, setSoft] = useState(0)
  const [steal, setSteal] = useState(0)
  const [guest, setGuest] = useState(0)
  const [gnice, setGnice] = useState(0)
  const [idle, setidle] = useState(0)

  const chartCpuData = {
    exportEnabled: true,
    animationEnabled: true,
    
    data: [{
      type: "pie",
      startAngle: 75,
      toolTipContent: "<b>{label}</b>: {y}%",
      showInLegend: "true",
      legendText: "{label}",
      indexLabelFontSize: 16,
      indexLabel: "{label} - {y}%",
      dataPoints: [
        { y: usr, label: "%usr" },
        { y: nice, label: "%nice" },
        { y: sys, label: "%sys" },
        { y: ioWait, label: "%iowait" },
        { y: irq, label: "%irq" },
        { y: soft, label: "%soft" },
        { y: steal, label: "%steal" },
        { y: guest, label: "%guest" },
        { y: gnice, label: "%gnice" },
        { y: idle, label: "%idle" },
      ]
    }]
  }

  useEffect(()=>{
    updateCpuData();
  },[])
  useEffect(() => {
    setInterval(() => {
      updateCpuData();
    }, 22000)

  });

  async function updateCpuData(){
    const response = await fetch('http://localhost:8080/api/v1/cpuData');
    
    const body = await response.json();
    cpuData = body;
    //console.log(cpuData.length);
    //console.log(cpuData);
    setUsr(parseInt(cpuData[0].usr))
    setNice(parseInt(cpuData[0].nice))
    setSys(parseInt(cpuData[0].sys))
    setIowait(parseInt(cpuData[0].ioWait))
    setIrq(parseInt(cpuData[0].irq))
    setSoft(parseInt(cpuData[0].soft))
    setSteal(parseInt(cpuData[0].steal))
    setGuest(parseInt(cpuData[0].guest))
    setGnice(parseInt(cpuData[0].gnice))
    setidle(parseInt(cpuData[0].idle))
    ////console.log(usr, nice, sys, ioWait, irq, soft, steal, guest, gnice, idle); 
  }

  var ioData = []
  var ioDataDevice = []
  

  async function updateIoData(){
    const response = await fetch('http://localhost:8080/api/v1/ioData');
    const body = await response.json();
    ioData= body;
    //console.log(ioData);
    ioData.map( data => 
      ioDataDevice.push(data.device_col)
    )
    console.log(ioDataDevice)
  }

  useEffect(()=>{
    updateIoData();
  },[])


const { currentUser } = useAuth()

function addSystem(){
    db.collection("Systems")
    .doc(currentUser.uid)
    .collection('userSystems')
    .doc('noOfSystem')
    .get()
    .then(doc => {
        const data = doc.data();
        var no = data.noOfSystems;
        no += 1;
        db.collection("Systems").doc(currentUser.uid).collection('userSystems').doc('system'+no).set({
            name: "system" + no,
            id: currentUser.uid + "system" + no
        })
        .then(function() {
            console.log("Document successfully written!");
            db.collection("Systems").doc(currentUser.uid).collection('userSystems').doc('noOfSystem').set({
                noOfSystems:no
            })
            .then(function() {
                console.log("number of system updated");
            })
            .catch(function(error) {
                console.error("Error changing the number of system: ", error);
            });
        })
        .catch(function(error) {
            console.error("Error writing document: ", error);
        });
    });
    
}

function downloadConfigFile(){
  var temp = "";
  db.collection("Systems")
  .doc(currentUser.uid)
  .collection('userSystems')
  .where("id", "!=", null)
  .get()
  .then(querySnapshot => {
    const data = querySnapshot.docs.map(doc => doc.data());
    for(var i=0;i<data.length;i++){
      temp += (data[i].id + '\n');
    }
    const element = document.createElement("a");
    const file = new Blob([currentUser.uid+('\n')+temp], {type: 'text/plain;charset=utf-8'});
    element.href = URL.createObjectURL(file);
    element.download = "config.txt";
    document.body.appendChild(element);
    element.click();
  });
}


const history = useHistory()

// const [iodelay,setIoDelay] = useState("9");
// const [cpu,setCpu] = useState("2");
// const [priority,setPriority] = useState("-");
// const [policy,setPolicy] = useState("-");
// const [command,setCommand] = useState("irqbalance");
// const [cpuPercentage,setCpuPercentage] = useState("0.03 %");

const currentdate = new Date().toDateString();

// function firstClicked() {
//   setCommand("migration/0");
//   setIoDelay("-");
//   setCpu("0");
//   setCpuPercentage("0.00 %");
//   setPriority("99");
//   setPolicy("FIFO");
// }

// function secondClicked() {
//   setCommand("migration/0");
//   setIoDelay("-");
//   setCpu("1");
//   setCpuPercentage("0.01 %");
//   setPriority("50");
//   setPolicy("FIFO");
// }

// function thirdClicked() {
//   setCommand("irqbalance");
//   setIoDelay("9");
//   setCpu("2");
//   setCpuPercentage("0.00 %");
//   setPriority("-");
//   setPolicy("-");
// }

// function fourthClicked() {
//   setCommand("NetworkManager");
//   setIoDelay("301");
//   setCpu("0");
//   setCpuPercentage("0.00 %");
//   setPriority("-");
//   setPolicy("-");
// }

// function fifthClicked() {
//   setCommand("gdm3");
//   setIoDelay("7");
//   setCpu("3");
//   setCpuPercentage("0.00 %");
//   setPriority("-");
//   setPolicy("-");
// }

// function sixthClicked() {
//   setCommand("whoopsie");
//   setIoDelay("43");
//   setCpu("3");
//   setCpuPercentage("0.00 %");
//   setPriority("-");
//   setPolicy("-");
// }

// function seventhClicked() {
//   setCommand("dbus-daemon");
//   setIoDelay("28");
//   setCpu("0");
//   setCpuPercentage("0.00 %");
//   setPriority("-");
//   setPolicy("-");
// }

const imageClick = () => {
  history.push("/dashboard")
} 
  return (
    <div className='home'>
      <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
        <Navbar className="nav-color">
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Form className="mr-auto form">
              <FormControl type="text" placeholder="Search" className="my-search"/>
            </Form>
            <FiIcons.FiPlusCircle size='1.5rem' className="icon-left" onClick={addSystem}/>
            <FiIcons.FiSettings size='1.5rem' className="icon-right" onClick={downloadConfigFile}/>
            <Image src={require('../../images/profile50x50.png')} onClick={() => imageClick()} roundedCircle/>
          </Navbar.Collapse>
        </Navbar>
      </Container>
      <Container fluid>
        <Row className="heading">
          <Col>
            <h1>Dashboard</h1>
            <h5>{currentdate}</h5>
          </Col>
        </Row>

        <Row>
          <Col md={5}>
            <div className="box4">
              <Container style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  Memstat
                </h3>
                <Row>
                  <Col style={{padding:48}}>
                    <div id='memDataId'>
                     { <CanvasJSChart options = {memData} onRef={ref => chart.current = ref} /> }
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>
          </Col>

          <Col>
          <div className="box4">
              <Container style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  CPU Stats
                </h3>
                <Row>
                  <Col style={{padding:48}}>
                    <CanvasJSChart options = {chartCpuData} onRef={ref => chart.current = ref}/>
                  </Col>
                </Row>
              </Container>
            </div>
          </Col>
        </Row>
        
        <Row className="row-margin">
          <Col md={8}>
            <div className="box4">
              <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  IO Stat
                </h3>
                <DeviceList />
              </Container>
            </div>
          </Col >

          <Col md={4}>
            <div className="box4">
              <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
                <h3 className="heading-w-bg">
                  Disk Stat
                </h3>
              <Row>
              <Col style={{padding:20}}>
                <Container fluid>
                  <Row>
                    <Col>
                      <CanvasJSChart options = {chartDiskData} onRef={ref => chart.current = ref} />
                    </Col>
                  </Row>
                </Container>  
              </Col>
                </Row>
              </Container>
            </div>
          </Col >
        </Row>
      </Container>
    </div>
  );
}

export default Home;
