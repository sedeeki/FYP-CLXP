import React, { Component } from 'react';
import './../ResourceMonitor/ResourceMonitor.css'
import './StatementCompare.css'
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend, ResponsiveContainer } from 'recharts';
import { Container, Row, Col, Button, DropdownButton, Dropdown } from 'react-bootstrap';

class StatementCompare extends Component {

    state = {
        index : 0,
        groups: [],
    
        //STATEMENT ANALYSIS DATA
        statementAnalysisGroups : [],
        statementAnalysisId : [],
        statementAnalysisAverageLatency : [],
        statementAnalysisTotalLatency : [],
        statementAnalysisDatabase : [],
        statementAnalysisErrorCount : [],
        statementAnalysisExecutionCount : [],
        statementAnalysisLockLatency : [],
        statementAnalysisMaxLatency : [],
        statementAnalysisQuery : [],
        statementAnalysisRowsAffected : [],
        statementAnalysisRowsSent : [],
        statementAnalysisRowsExamined : [],
    
        firstIndexofList : 0,
        secondIndexofList :  0,
        listSelected : false,

        firstDropDownValue: "Select a Statement",
        secondDropDownValue: "Select a Statement",
    };
  
    async componentDidMount() {
        const statementAnalysisresponse = await fetch('http://localhost:8080/api/v1/StatementAnalysis');
        const statementAnalysisbody = await statementAnalysisresponse.json();
        this.setState({ statementAnalysisGroups: statementAnalysisbody});

        
        for(var k=0 ; k<statementAnalysisbody.length ; k++){
            this.setState({ statementAnalysisId: this.state.statementAnalysisId.concat(statementAnalysisbody[k].id)});
            this.setState({ statementAnalysisQuery: this.state.statementAnalysisQuery.concat(statementAnalysisbody[k].query)});
            this.setState({ statementAnalysisAverageLatency: this.state.statementAnalysisAverageLatency.concat(statementAnalysisbody[k].avg_lat)});
            this.setState({ statementAnalysisTotalLatency: this.state.statementAnalysisTotalLatency.concat(statementAnalysisbody[k].total_lat)});
            this.setState({ statementAnalysisMaxLatency: this.state.statementAnalysisMaxLatency.concat(statementAnalysisbody[k].max_lat)});
            this.setState({ statementAnalysisLockLatency: this.state.statementAnalysisLockLatency.concat(statementAnalysisbody[k].lock_lat)});
            this.setState({ statementAnalysisErrorCount: this.state.statementAnalysisErrorCount.concat(statementAnalysisbody[k].err_count)});
            this.setState({ statementAnalysisExecutionCount: this.state.statementAnalysisExecutionCount.concat(statementAnalysisbody[k].exec_count)});
            this.setState({ statementAnalysisRowsAffected: this.state.statementAnalysisRowsAffected.concat(statementAnalysisbody[k].rows_affected)});
            this.setState({ statementAnalysisRowsSent: this.state.statementAnalysisRowsSent.concat(statementAnalysisbody[k].rows_sent)});
            this.setState({ statementAnalysisRowsExamined: this.state.statementAnalysisRowsExamined.concat(statementAnalysisbody[k].rows_examined)});
        }
    }

    firstDropdownItemClicked (new_index) {
        this.setState( {
            firstIndexofList: new_index,
            firstDropDownValue: "Statement " + (new_index + 1)
        });
    }

    secondDropdownItemClicked (new_index) {
        this.setState( {
            secondIndexofList: new_index,
            secondDropDownValue: "Statement " + (new_index + 1)
        });
    }

    compareButtonClicked () {
        this.setState( {
            listSelected: true,
        });
    }

    selectStatementClicked () {
        this.setState( {
            listSelected: false,
        });
    }


  
    render() {
        const {
            statementAnalysisId,
            statementAnalysisGroups,
            statementAnalysisAverageLatency,
            statementAnalysisTotalLatency,
            statementAnalysisLockLatency,
            statementAnalysisMaxLatency,
        } = this.state;
      
        const {
            firstIndexofList,
            secondIndexofList,
            listSelected
        } = this.state;

        const data = [
        {
            subject: 'Avg Latency',
            A: statementAnalysisAverageLatency[firstIndexofList],
            B: statementAnalysisAverageLatency[secondIndexofList],
            fullMark: 150,
        },
        {
            subject: 'Total Latency',
            A: statementAnalysisTotalLatency[firstIndexofList],
            B: statementAnalysisTotalLatency[secondIndexofList],
            fullMark: 150,
        },
        {
            subject: 'Lock Latency',
            A: statementAnalysisLockLatency[firstIndexofList],
            B: statementAnalysisLockLatency[secondIndexofList],
            fullMark: 150,
        },
        {
            subject: 'Max Latency',
            A: statementAnalysisMaxLatency[firstIndexofList],
            B: statementAnalysisMaxLatency[secondIndexofList],
            fullMark: 150,
        },
        ];

        
        if (listSelected) {
            return (
                <Row className="justify-content-center">
                    <Col md={12}>
                        <Row className="justify-content-end">
                            <Col md={2}>
                                    <Button variant="outline-secondary" action onClick={() => this.selectStatementClicked()}>
                                        Go Back
                                    </Button>
                            </Col>
                        </Row> 
                        <Row>
                            <Col md={12}>
                                <div className="testing-div">
                                    <ResponsiveContainer>
                                        <RadarChart cx="50%" cy="50%" width={730} height={250} outerRadius="80%" data={data}>
                                            <PolarGrid />
                                            <PolarAngleAxis dataKey="subject" />
                                            <PolarRadiusAxis angle={30} domain={[0, 150]} />
                                            <Radar name={"Statement " + statementAnalysisId[firstIndexofList]} dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                                            <Radar name={"Statement " + statementAnalysisId[secondIndexofList]} dataKey="B" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                                            <Legend layout="vetical" verticalAlign="middle" align="left" />
                                        </RadarChart>
                                    </ResponsiveContainer>
                                </div>
                            </Col>
                        </Row>
                    </Col>
                </Row>
            );
        }
    
        else {
            return (
                <div className="list-selector-component">
                    <Container>
                        <Row className="justify-content-md-center statement-compare-rows compare-button">
                            <Col md="auto">
                                <DropdownButton id="dropdown-basic-button first-dropdown" variant="secondary" title={this.state.firstDropDownValue} size="lg">
                                    {statementAnalysisGroups.map( (statementAnalysisGroups,index) =>
                                        <Dropdown.Item ref={this.myRef} action onClick={() => this.firstDropdownItemClicked(index)}>
                                            {statementAnalysisGroups.id}
                                        </Dropdown.Item>
                                    )}
                                </DropdownButton>
                            </Col>

                            <Col md="auto">
                                <DropdownButton id="dropdown-basic-button second-dropdown" variant="secondary" title={this.state.secondDropDownValue} size="lg">
                                    {statementAnalysisGroups.map( (statementAnalysisGroups,index) =>
                                        <Dropdown.Item action onClick={() => this.secondDropdownItemClicked(index)}>
                                            {statementAnalysisGroups.id}
                                        </Dropdown.Item>
                                    )}
                                </DropdownButton>
                            </Col>
                        </Row>

                        <Row className="justify-content-md-center statement-compare-rows compare-button">
                            <Col md="auto">
                                <Button variant="outline-secondary" action onClick={() => this.compareButtonClicked()}>
                                    Compare
                                </Button>
                            </Col>
                        </Row>
                    </Container>
                </div>
            );
        }
        
    }
  }
  
  export default StatementCompare;