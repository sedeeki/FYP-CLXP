import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom';
import Sidebar from './components/Sidebar/Sidebar';
import ResourceMoniter from './components/ResourceMonitor/ResourceMonitor'
import CodeProfiler from './components/CodeProfiler/CodeProfiler';
import Predictions from './components/Predictions/Predictions';
import Home from './components/Home/Home';
import Register from './components/Register/register';
import { Component } from 'react';
import AuthService from './services/auth.service';
import BoardHome from './components/Board-Home/board-home';
import BoardAdmin from './components/Board-Admin/board-admin';
import BoardModerator from './components/Board-Moderator/board-moderator';
import BoardUser from './components/Board-User/board-user';
import Login from './components/Login/login';
import Profile from './components/Profile/profile'

class App extends Component {
  constructor(props) {
    super(props); 
    this.logOut = this.logOut.bind(this);

    this.state = {
      showModeratorBoard: false,
      showAdminBoard: false,
      currentUser: undefined,
    };
  }

  componentDidMount(){
    const user = AuthService.getCurrentUser();

    if(user) {
      this.setState({
        currentUser: AuthService.getCurrentUser(),
        showModeratorBoard: user.roles.includes("ROLE_MODERATOR"),
        showAdminBoard: user.roles.includes("ROLE_ADMIN")
      });
    }
  }

  logOut(){
    AuthService.logout();
  }

  render() {

    const { currentUser, showModeratorBoard, showAdminBoard } = this.state;

    return (
      <div className="App">
        {/* <Router>
          <Sidebar />
          <Switch>
            <Route path='/' exact component={Home}/>
            <Route path='/resourcemonitor' component={ResourceMoniter}/>
            <Route path='/codeprofiler' component={CodeProfiler}/>
            <Route path='/predictions' component={Predictions}/>
            <Route path='/register' component={Register}/>
          </Switch>
        </Router> */}
        <Router>
          <div>
            <nav className="navbar navbar-expand navbar-dark bg-dark">
              <Link to={"/"} className="narvbar-brand">
                Cloud Xplor
              </Link>
              <div className="navbar-nav mr-auto">
                <li className="nav-item">
                  <Link to={"/boardhome"} className="nav-link">
                    BoardHome                  
                  </Link>
                </li>

                {showModeratorBoard && (
                  <li className="nav-item">
                    <Link to={"/mod"} className="nav-link">
                      Moderator Board
                    </Link>
                  </li>
                )}

                {showAdminBoard && (
                  <li className="nav-item">
                    <Link to={"/admin"} className="nav-link">
                      Admin Board
                    </Link>
                  </li>
                )}

                {currentUser && (
                  <li className="nav-item">
                    <Link to={"/user"} className="nav-link">
                      User
                    </Link>
                  </li>
                )}
              </div>
              
              {currentUser ? (
                <div className="navbar-nav ml-auto">
                  <li className="nav-item">
                    <Link to={"/profile"} className="nav-link">
                      {currentUser.username}
                    </Link>
                  </li>

                  <li className="nav-item">
                    <a href="/login" className="nav-link" onClick={this.logOut}>
                      LogOut
                    </a>
                  </li>
                </div>
              ) : (
                <div className="navbar-nav ml-auto">
                  <li className="nav-item">
                    <Link to={"/login"} className="nav-link">
                      Login
                    </Link>
                  </li>
                    
                  <li className="nav-item">
                    <Link to={"/register"} className="nav-link">
                      Sign Up
                    </Link>
                  </li>
                </div>
              )}
            </nav>
            <div className="container mt-3">
              <Switch>
                <Route exact path={["/", "/boardhome"]} component={BoardHome}/>
                <Route exact path="/login" component={Login}/>
                <Route exact path="/register" component={Register}/>
                <Route exact path="/profile" component={Profile}/> 
                <Route path="/user" component={BoardUser}/>
                <Route path="/mod" component={BoardModerator}/>
                <Route path="/admin" component={BoardAdmin}/>
              </Switch>
            </div>
          </div>
        </Router>
      </div>
    );
  }
  
}

export default App;
